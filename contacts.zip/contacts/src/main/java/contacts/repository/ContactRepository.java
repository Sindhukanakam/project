package contacts.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import contacts.model.Contact;

public interface ContactRepository extends JpaRepository<Contact, Long> {
}
