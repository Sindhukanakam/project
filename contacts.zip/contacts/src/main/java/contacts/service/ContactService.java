package contacts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import contacts.model.Contact;
import contacts.repository.ContactRepository;

import java.time.LocalDateTime;

@Service
public class ContactService {
    @Autowired
    private ContactRepository contactRepository;

    public Contact addContact(Contact contact) {
        contact.setDateCreated(LocalDateTime.now());
        return contactRepository.save(contact);
    }

    public Contact updateContact(Long id, Contact updatedContact) {
        Contact existingContact = contactRepository.findById(id).orElse(null);
        if (existingContact != null) {
            // Update only the fields that are not null in the updated contact
            if (updatedContact.getName() != null) {
                existingContact.setName(updatedContact.getName());
            }
            if (updatedContact.getCategory() != null) {
                existingContact.setCategory(updatedContact.getCategory());
            }
            if (updatedContact.getPhoneNumber() != null) {
                existingContact.setPhoneNumber(updatedContact.getPhoneNumber());
            }
            if (updatedContact.getEmail() != null) {
                existingContact.setEmail(updatedContact.getEmail());
            }
            if (updatedContact.getCountry() != null) {
                existingContact.setCountry(updatedContact.getCountry());
            }
            return contactRepository.save(existingContact);
        } else {
            return null; // or throw an exception if needed
        }
    }
}
