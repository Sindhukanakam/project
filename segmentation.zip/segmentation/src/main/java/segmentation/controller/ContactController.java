
package segmentation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import segmentation.model.Contact;
import segmentation.model.SegmentedContact;
import segmentation.service.ContactService;

import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api/contacts")
public class ContactController {
    @Autowired
    private ContactService contactService;

    @GetMapping("segmentation/{segmentType}")
    public ResponseEntity<List<Contact>> segmentContacts(@PathVariable String segmentType,
                                                          @RequestParam(required = false) String value,
                                                          @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fromDate,
                                                          @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date toDate) {
        List<Contact> segmentedContacts;
        if ("category".equals(segmentType)) {
            segmentedContacts = contactService.segmentContactsByCategory(value);
        } else if ("country".equals(segmentType)) {
            segmentedContacts = contactService.segmentContactsByCountry(value);
        } else if ("date".equals(segmentType)) {
            segmentedContacts = contactService.segmentContactsByDate(fromDate, toDate);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        
        contactService.saveContacts(segmentedContacts);

        return new ResponseEntity<>(segmentedContacts, HttpStatus.OK);
    }

    @PostMapping("/segmentation/save")
    public ResponseEntity<String> saveSegmentedData(@RequestBody List<SegmentedContact> segmentedData) {
        
        contactService.saveSegmentedContacts(segmentedData);
        return ResponseEntity.ok("Segmented data saved successfully.");
    }
}
